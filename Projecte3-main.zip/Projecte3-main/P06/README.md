A la tasca “T06: Fonaments del DNS” heu realitzat un vídeo dins l’encàrrec que Digicorp va sol·licitar a EverPia per la formació del seu personal tècnic en els conceptes bàsics del servei del sistema de noms (DNS).
Doncs bé, aquest vídeo és un producte del qual podeu estar orgullosos i per tant, que voleu incorporar al vostre port foli personal. Recordeu que sobreviure en una consultora i progressar professionalment, implica crear-se un currículum amb les millors accions que aneu realitzant al llarg de la vostra estada.

Tal com es va indicar a la tasca, pengeu el vídeo en alguna plataforma, per exemple, podeu Stream que forma part del vostre Office 365. Assegureu-vos de donar permisos de visualització. 

### Link de la tasca:
